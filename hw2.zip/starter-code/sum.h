#include<vector>

std::vector<uint> serialSum(const std::vector<uint> &v) 
{
    std::vector<uint> sums(2);
    // TODO
    return sums;
}

std::vector<uint> parallelSum(const std::vector<uint> &v) 
{
    std::vector<uint> sums(2);
    // TODO
    return sums;
}